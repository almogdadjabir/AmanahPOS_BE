'use client';

import { useTranslations } from 'next-intl';
import Logo from '@/components/ui/Logo';
import LocaleSwitcher from '@/components/ui/LocaleSwitcher';
import FadeIn from '@/components/ui/FadeIn';

const NAV_LINKS = [
  { key: 'features', href: '#features' },
  { key: 'pricing',  href: '#pricing'  },
  { key: 'contact',  href: '#contact'  },
] as const;

export default function Footer() {
  const t = useTranslations('footer');

  return (
    <footer className="border-t" style={{ background: '#FFFFFF', borderTopColor: '#F1F5F9' }}>
      <div className="container-page py-10">
        <FadeIn className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">

          {/* Brand */}
          <div>
            <a href="#" className="inline-flex items-center gap-2 no-underline mb-2">
              <Logo size={26} />
              <span className="font-black text-[14px] tracking-tight text-[#0F172A]">AmanaPOS</span>
            </a>
            <p className="text-[12.5px] leading-relaxed text-[#94A3B8] max-w-[230px]">
              {t('tagline')}
            </p>
          </div>

          {/* Nav links + locale switcher */}
          <div className="flex flex-wrap items-center gap-5">
            {NAV_LINKS.map(({ key, href }) => (
              <a
                key={key}
                href={href}
                className="text-[13px] font-semibold text-[#64748B] hover:text-[#0F172A] no-underline transition-colors duration-150"
              >
                {t(`links.${key}`)}
              </a>
            ))}
            <LocaleSwitcher />
          </div>
        </FadeIn>

        {/* Bottom copyright */}
        <div className="mt-8 pt-6 border-t border-[#F1F5F9]">
          <p className="text-[12px] font-medium text-[#CBD5E1] text-center">
            {t('copyright')}
          </p>
        </div>
      </div>
    </footer>
  );
}
