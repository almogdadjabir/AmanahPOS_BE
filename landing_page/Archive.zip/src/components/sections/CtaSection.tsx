'use client';

import { useTranslations } from 'next-intl';
import FadeIn from '@/components/ui/FadeIn';

const DASHBOARD_URL = process.env.NEXT_PUBLIC_DASHBOARD_URL ?? '#';

export default function CtaSection() {
  const t = useTranslations('ctaSection');

  return (
    <section
      id="cta"
      className="relative py-24 lg:py-28 overflow-hidden"
      style={{ background: '#0D9488' }}
    >
      {/* Subtle noise texture overlay */}
      <div
        aria-hidden
        className="absolute inset-0 pointer-events-none opacity-[0.04]"
        style={{
          backgroundImage:
            'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 256 256\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noise\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noise)\'/%3E%3C/svg%3E")',
          backgroundRepeat: 'repeat',
          backgroundSize: '128px 128px',
        }}
      />

      <div className="container-page relative z-10">
        <FadeIn className="text-center max-w-2xl mx-auto">
          <h2
            className="font-black tracking-tight text-white text-balance"
            style={{ fontSize: 'clamp(26px, 3.5vw, 46px)', lineHeight: 1.1 }}
          >
            {t('title')}
          </h2>
          <div className="mt-9">
            <a
              href={DASHBOARD_URL}
              className="inline-flex items-center gap-2.5 px-8 py-4 rounded-xl text-[15px] font-black bg-white text-[#0D9488] no-underline shadow-[0_4px_24px_rgba(0,0,0,0.12)] hover:-translate-y-0.5 transition-transform duration-200 select-none"
            >
              {t('cta')}
              <ArrowIcon />
            </a>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}

function ArrowIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="flip-rtl">
      <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
