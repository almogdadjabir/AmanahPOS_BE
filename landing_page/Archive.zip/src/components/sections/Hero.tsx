'use client';

import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, Play, ShoppingCart, TrendingUp } from 'lucide-react';
import { useTranslations } from 'next-intl';

type Stat = { value: string; label: string };

const EASE = [0.4, 0, 0.2, 1] as [number, number, number, number];

const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.06 } },
};

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.52, ease: EASE } },
};

const DASHBOARD_URL = process.env.NEXT_PUBLIC_DASHBOARD_URL ?? '#';

export default function Hero() {
  const t       = useTranslations('hero');
  const tRoot   = useTranslations();
  const stats   = tRoot.raw('heroStats') as Stat[];
  const reduced = useReducedMotion();

  return (
    <section
      className="relative overflow-hidden bg-white"
      style={{ minHeight: '92vh' }}
    >
      {/* Subtle top border accent */}
      <div
        aria-hidden
        className="absolute top-0 left-0 right-0 h-px"
        style={{ background: 'linear-gradient(90deg, transparent 0%, #0D9488 50%, transparent 100%)' }}
      />

      <div className="container-page relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-8 items-center py-20 lg:py-28">

        {/* ── Left: Copy ─────────────────────────────────────────────── */}
        <motion.div
          variants={reduced ? {} : stagger}
          initial="hidden"
          animate="show"
          className="max-w-[560px]"
        >
          {/* Eyebrow */}
          <motion.div variants={reduced ? {} : fadeUp}>
            <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-[11px] font-extrabold uppercase tracking-widest bg-[#F0FDFA] text-[#0F766E] border border-[#CCFBF1]">
              <span
                className="w-1.5 h-1.5 rounded-full bg-[#0F766E] shrink-0"
                style={{ animation: 'dot-pulse 2s ease-in-out infinite' }}
              />
              {t('eyebrow')}
            </span>
          </motion.div>

          {/* H1 */}
          <motion.h1
            variants={reduced ? {} : fadeUp}
            className="mt-5 leading-[1.06] tracking-[-2px] text-balance text-[#0F172A]"
            style={{ fontSize: 'clamp(36px, 5vw, 62px)', fontWeight: 900 }}
          >
            {t('title')}{' '}
            <span className="text-[#0D9488]">{t('titleAccent')}</span>
          </motion.h1>

          {/* Description */}
          <motion.p
            variants={reduced ? {} : fadeUp}
            className="mt-5 leading-[1.8] text-pretty text-[#4E5A6B]"
            style={{ fontSize: 'clamp(15px, 1.35vw, 17px)', fontWeight: 450 }}
          >
            {t('description')}
          </motion.p>

          {/* CTAs */}
          <motion.div variants={reduced ? {} : fadeUp} className="flex flex-wrap gap-3 mt-8">
            <a
              href={DASHBOARD_URL}
              className="btn-primary inline-flex items-center gap-2 px-6 py-3 rounded-xl text-[14.5px] font-bold text-white no-underline transition-all duration-200 hover:-translate-y-0.5 select-none"
            >
              {t('ctaPrimary')}
              <ArrowRight size={15} strokeWidth={2.5} />
            </a>
            <a
              href="#how"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl text-[14.5px] font-semibold no-underline bg-white text-[#64748B] border border-[#E2E8F0] hover:text-[#0F172A] hover:border-[#CBD5E1] transition-all duration-150 select-none"
            >
              <Play size={13} strokeWidth={2} className="fill-current" />
              {t('ctaSecondary')}
            </a>
          </motion.div>

          {/* Stats */}
          <motion.div
            variants={reduced ? {} : fadeUp}
            className="mt-10 pt-8 flex flex-wrap gap-8"
            style={{ borderTop: '1px solid rgba(15,23,42,0.07)' }}
          >
            {stats.map((stat) => (
              <div key={stat.label}>
                <div
                  className="font-black tracking-tight text-[#0F172A]"
                  style={{ fontSize: 'clamp(18px, 1.8vw, 24px)' }}
                >
                  {stat.value}
                </div>
                <div className="text-[10.5px] font-bold uppercase tracking-[0.12em] text-[#94A3B8] mt-0.5">
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </motion.div>

        {/* ── Right: Single phone frame ───────────────────────────────── */}
        <motion.div
          className="flex justify-center lg:justify-end"
          initial={reduced ? false : { opacity: 0, y: 24 }}
          animate={reduced ? {} : { opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.22, ease: EASE }}
        >
          <PhoneFrame reduced={!!reduced} />
        </motion.div>
      </div>
    </section>
  );
}

/* ── Phone frame ──────────────────────────────────────────────────────── */

function PhoneFrame({ reduced }: { reduced: boolean }) {
  return (
    <motion.div
      className="relative shrink-0 rounded-[28px] overflow-hidden bg-white"
      style={{
        width: 240,
        height: 460,
        boxShadow:
          '0 32px 80px -16px rgba(13,148,136,0.22), ' +
          '0 8px 32px -4px rgba(15,23,42,0.10), ' +
          '0 0 0 1px rgba(13,148,136,0.10)',
      }}
      animate={reduced ? {} : { y: [0, -10, 0] }}
      transition={reduced ? {} : { duration: 5.5, repeat: Infinity, ease: 'easeInOut' }}
    >
      <POSScreen />
    </motion.div>
  );
}

/* ── POS Screen ───────────────────────────────────────────────────────── */

const POS_PRODUCTS = [
  { name: 'Cappuccino', price: '2,200', bg: '#F0FDFA', tint: '#0F766E' },
  { name: 'Karak Tea',  price: '1,200', bg: '#FEF9EC', tint: '#D97706' },
  { name: 'Croissant',  price: '1,800', bg: '#FDF2F8', tint: '#DB2777' },
  { name: 'Latte',      price: '2,400', bg: '#F0F9FF', tint: '#0284C7' },
] as const;

function POSScreen() {
  return (
    <div className="h-full flex flex-col bg-[#F8FAFC]">
      {/* Status bar */}
      <div className="bg-white px-3 pt-5 pb-2.5 border-b border-[#F1F5F9]">
        <div className="flex items-center gap-2 mb-2.5">
          <div className="w-5 h-5 rounded-md bg-[#0D9488] grid place-items-center shrink-0">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none">
              <path d="M9 22V12h6v10M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[9px] font-black text-[#0F172A]">AmanaPOS</p>
            <p className="text-[7px] text-[#64748B]">Khartoum · Branch 1</p>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#0D9488]" style={{ animation: 'dot-pulse 2s ease-in-out infinite' }} />
            <span className="text-[6.5px] font-bold text-[#0D9488]">Online</span>
          </div>
        </div>
        {/* Category tabs */}
        <div className="flex gap-1.5 overflow-hidden">
          {(['All', 'Coffee', 'Tea', 'Food'] as const).map((label, i) => (
            <div
              key={label}
              className="px-2 py-0.5 rounded-full text-[7px] font-bold shrink-0"
              style={i === 0
                ? { background: '#0D9488', color: 'white' }
                : { background: '#F1F5F9', color: '#64748B' }}
            >
              {label}
            </div>
          ))}
        </div>
      </div>

      {/* Product grid */}
      <div className="flex-1 overflow-hidden px-2.5 pt-2 pb-16">
        <div className="grid grid-cols-2 gap-1.5">
          {POS_PRODUCTS.map(({ name, price, bg, tint }) => (
            <div key={name} className="bg-white rounded-[10px] p-1.5 border border-[#F1F5F9]">
              <div className="aspect-[1.25] rounded-md mb-1.5" style={{ background: bg }} />
              <p className="text-[7.5px] font-extrabold text-[#0F172A] leading-tight truncate">{name}</p>
              <p className="text-[7px] font-bold mt-0.5" style={{ color: tint }}>
                {price} <span className="text-[5.5px] text-[#94A3B8] font-medium">SDG</span>
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Cart bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-[18px] px-3 py-2.5 shadow-[0_-6px_20px_rgba(0,0,0,0.06)] flex items-center gap-2">
        <div className="w-7 h-7 rounded-lg bg-[#F0FDFA] flex items-center justify-center shrink-0">
          <ShoppingCart size={12} className="text-[#0D9488]" strokeWidth={2.2} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[6.5px] text-[#64748B]">4 items</p>
          <p className="text-[10.5px] font-black text-[#0F172A] leading-tight">
            7,400 <span className="text-[5.5px] text-[#94A3B8] font-medium">SDG</span>
          </p>
        </div>
        <div
          className="text-white rounded-lg px-2.5 py-1.5 text-[7.5px] font-black"
          style={{ background: 'linear-gradient(135deg, #0F766E, #0D9488)' }}
        >
          Checkout
        </div>
      </div>
    </div>
  );
}
