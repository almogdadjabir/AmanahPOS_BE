'use client';

import { useTranslations } from 'next-intl';
import FadeIn from '@/components/ui/FadeIn';
import { ShoppingCart, Wifi, Package } from 'lucide-react';

type Block = { eyebrow: string; title: string; body: string; screenshotAlt: string };

const SCREENS = [OfflineScreen, BusinessTypeScreen, PaymentScreen] as const;

export default function Features() {
  const t      = useTranslations('features');
  const blocks = t.raw('blocks') as Block[];

  return (
    <section id="features" className="relative bg-white py-24 lg:py-32">
      <div className="container-page">

        {/* Section header */}
        <FadeIn className="text-center mb-20">
          <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-[11px] font-extrabold uppercase tracking-widest bg-[#F0FDFA] text-[#0F766E] border border-[#CCFBF1] mb-5">
            {t('eyebrow')}
          </span>
          <h2
            className="font-black tracking-tight text-[#0F172A] text-balance"
            style={{ fontSize: 'clamp(26px, 3.5vw, 44px)', lineHeight: 1.1 }}
          >
            {t('title')}
          </h2>
          <p className="mt-4 text-[#475569] font-medium leading-relaxed max-w-xl mx-auto text-pretty">
            {t('subtitle')}
          </p>
        </FadeIn>

        {/* Alternating blocks */}
        <div className="flex flex-col gap-20 lg:gap-28">
          {blocks.map((block, i) => {
            const Screen = SCREENS[i];
            const isOdd  = i % 2 === 1;

            return (
              <FadeIn key={block.title} className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">

                {/* Text — start on even, end on odd (flip with order) */}
                <div className={isOdd ? 'lg:order-2' : ''}>
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10.5px] font-extrabold uppercase tracking-widest bg-[#F0FDFA] text-[#0F766E] border border-[#CCFBF1] mb-4">
                    {block.eyebrow}
                  </span>
                  <h3
                    className="font-black tracking-tight text-[#0F172A] text-balance leading-tight"
                    style={{ fontSize: 'clamp(22px, 2.5vw, 34px)' }}
                  >
                    {block.title}
                  </h3>
                  <p className="mt-4 text-[#475569] leading-[1.8] text-pretty" style={{ fontSize: 'clamp(14px, 1.1vw, 16px)' }}>
                    {block.body}
                  </p>
                </div>

                {/* Phone frame */}
                <div className={`flex justify-center ${isOdd ? 'lg:order-1' : ''}`}>
                  <div
                    aria-label={block.screenshotAlt}
                    className="relative rounded-[28px] overflow-hidden bg-white shrink-0"
                    style={{
                      width: 240,
                      height: 440,
                      boxShadow:
                        '0 24px 64px -12px rgba(13,148,136,0.16), ' +
                        '0 6px 20px -4px rgba(15,23,42,0.08), ' +
                        '0 0 0 1px rgba(13,148,136,0.08)',
                    }}
                  >
                    <Screen />
                  </div>
                </div>
              </FadeIn>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ── Screen 1: Offline Mode ───────────────────────────────────────────── */

const OFFLINE_PRODUCTS = [
  { name: 'Cappuccino', price: '2,200', bg: '#F0FDFA' },
  { name: 'Karak Tea',  price: '1,200', bg: '#FEF9EC' },
  { name: 'Croissant',  price: '1,800', bg: '#FDF2F8' },
  { name: 'Latte',      price: '2,400', bg: '#F0F9FF' },
] as const;

function OfflineScreen() {
  return (
    <div className="h-full flex flex-col bg-[#F8FAFC]">
      {/* Header */}
      <div className="bg-white px-3 pt-5 pb-2.5 border-b border-[#F1F5F9]">
        <div className="flex items-center justify-between mb-2">
          <div>
            <p className="text-[9px] font-black text-[#0F172A]">AmanaPOS</p>
            <p className="text-[7px] text-[#64748B]">Khartoum · Branch 1</p>
          </div>
          {/* Offline badge */}
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#FEF9EC] border border-[#FDE68A]">
            <Wifi size={8} className="text-[#D97706]" strokeWidth={2.5} />
            <span className="text-[6.5px] font-bold text-[#D97706]">Offline</span>
          </div>
        </div>
        {/* Sync banner */}
        <div className="rounded-md bg-[#FFFBEB] border border-[#FDE68A] px-2 py-1.5">
          <p className="text-[7px] font-bold text-[#B45309]">3 sales stored locally · will sync when online</p>
        </div>
      </div>

      {/* Products still accessible */}
      <div className="flex-1 px-2.5 pt-2.5">
        <p className="text-[7px] font-bold text-[#94A3B8] uppercase tracking-wide mb-2">Products</p>
        <div className="grid grid-cols-2 gap-1.5">
          {OFFLINE_PRODUCTS.map(({ name, price, bg }) => (
            <div key={name} className="bg-white rounded-[10px] p-1.5 border border-[#F1F5F9]">
              <div className="aspect-[1.25] rounded-md mb-1.5" style={{ background: bg }} />
              <p className="text-[7.5px] font-extrabold text-[#0F172A] leading-tight truncate">{name}</p>
              <p className="text-[7px] font-bold text-[#64748B] mt-0.5">{price} <span className="text-[5.5px] text-[#94A3B8]">SDG</span></p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="mx-2.5 mb-3 rounded-lg bg-white border border-[#F1F5F9] px-2.5 py-2 flex items-center justify-between">
        <div>
          <p className="text-[7px] font-bold text-[#0F172A]">3 pending sales</p>
          <p className="text-[6.5px] text-[#94A3B8]">Auto-sync on reconnect</p>
        </div>
        <div className="w-6 h-6 rounded-full bg-[#FFFBEB] flex items-center justify-center">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none">
            <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" stroke="#D97706" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>
    </div>
  );
}

/* ── Screen 2: Business Type Selector ────────────────────────────────── */

function BusinessTypeScreen() {
  return (
    <div className="h-full flex flex-col bg-[#F8FAFC]">
      {/* Header */}
      <div className="bg-white px-3 pt-5 pb-3 border-b border-[#F1F5F9]">
        <p className="text-[7px] font-semibold text-[#94A3B8] uppercase tracking-wide mb-0.5">Setup</p>
        <p className="text-[10px] font-black text-[#0F172A]">Choose your business type</p>
      </div>

      {/* Type cards */}
      <div className="flex-1 px-3 pt-4 space-y-2.5">

        {/* Restaurant — selected */}
        <div
          className="rounded-[14px] p-3 border-2"
          style={{ background: '#F0FDFA', borderColor: '#0D9488' }}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-7 h-7 rounded-xl bg-white flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                <path d="M18 8h1a4 4 0 0 1 0 8h-1M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8zM6 1v3M10 1v3M14 1v3" stroke="#0D9488" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div className="w-4 h-4 rounded-full bg-[#0D9488] flex items-center justify-center">
              <svg width="8" height="8" viewBox="0 0 24 24" fill="none">
                <path d="m5 12 5 5L20 7" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
          <p className="text-[9px] font-black text-[#0F172A]">Restaurant</p>
          <p className="text-[7px] text-[#64748B] mt-0.5 leading-relaxed">Menu-based ordering, no inventory complexity</p>
        </div>

        {/* Shop */}
        <div className="rounded-[14px] p-3 border border-[#E2E8F0] bg-white">
          <div className="flex items-center justify-between mb-2">
            <div className="w-7 h-7 rounded-xl bg-[#F8FAFC] flex items-center justify-center">
              <Package size={12} className="text-[#64748B]" strokeWidth={2} />
            </div>
            <div className="w-4 h-4 rounded-full border-2 border-[#E2E8F0]" />
          </div>
          <p className="text-[9px] font-black text-[#0F172A]">Shop / Retail</p>
          <p className="text-[7px] text-[#94A3B8] mt-0.5 leading-relaxed">Full stock tracking & barcode scanning</p>
        </div>

        {/* Features diff */}
        <div className="bg-white rounded-xl border border-[#F1F5F9] p-2.5 mt-1">
          <p className="text-[7px] font-bold text-[#94A3B8] uppercase tracking-wide mb-2">Included with Restaurant</p>
          {[['Menu management', true], ['Order receipts', true], ['Staff access', true], ['Inventory tracking', false]].map(([label, checked]) => (
            <div key={label as string} className="flex items-center gap-1.5 mb-1">
              <div className={`w-3 h-3 rounded-full flex items-center justify-center ${checked ? 'bg-[#F0FDFA]' : 'bg-[#F1F5F9]'}`}>
                {checked
                  ? <svg width="6" height="6" viewBox="0 0 24 24" fill="none"><path d="m5 12 5 5L20 7" stroke="#0D9488" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  : <svg width="5" height="5" viewBox="0 0 24 24" fill="none"><path d="M18 6 6 18M6 6l12 12" stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round"/></svg>
                }
              </div>
              <p className={`text-[7px] ${checked ? 'text-[#0F172A] font-medium' : 'text-[#94A3B8]'}`}>{label as string}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ── Screen 3: Payment Methods ────────────────────────────────────────── */

function PaymentScreen() {
  return (
    <div className="h-full flex flex-col bg-[#F8FAFC]">
      {/* Header */}
      <div className="bg-white px-3 pt-5 pb-3 border-b border-[#F1F5F9]">
        <p className="text-[7px] font-semibold text-[#94A3B8] uppercase tracking-wide mb-0.5">Checkout</p>
        <p className="text-[10px] font-black text-[#0F172A]">Choose payment</p>
      </div>

      {/* Order summary */}
      <div className="mx-3 mt-3 bg-white rounded-xl border border-[#F1F5F9] px-3 py-2.5">
        <div className="flex justify-between items-center mb-1">
          <p className="text-[7px] text-[#64748B] font-medium">Subtotal (4 items)</p>
          <p className="text-[7.5px] font-bold text-[#0F172A]">7,400 SDG</p>
        </div>
        <div className="flex justify-between items-center mb-2">
          <p className="text-[7px] text-[#64748B] font-medium">VAT 10%</p>
          <p className="text-[7.5px] font-bold text-[#0F172A]">740 SDG</p>
        </div>
        <div className="h-px bg-[#F1F5F9] mb-2" />
        <div className="flex justify-between items-center">
          <p className="text-[8px] font-black text-[#0F172A]">Total</p>
          <p className="text-[11px] font-black text-[#0F172A]">8,140 SDG</p>
        </div>
      </div>

      {/* Payment options */}
      <div className="flex-1 px-3 pt-3 space-y-2">
        <p className="text-[7px] font-bold text-[#94A3B8] uppercase tracking-wide mb-1.5">Select method</p>

        {/* Bankak — highlighted */}
        <div
          className="rounded-[12px] px-3 py-2.5 flex items-center gap-2.5 border-2"
          style={{ background: '#F0FDFA', borderColor: '#0D9488' }}
        >
          <div className="w-7 h-7 rounded-lg bg-white flex items-center justify-center shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <rect x="2" y="5" width="20" height="14" rx="2" stroke="#0D9488" strokeWidth="2"/>
              <path d="M2 10h20" stroke="#0D9488" strokeWidth="2"/>
              <path d="M6 15h4" stroke="#0D9488" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>
          <div className="flex-1">
            <p className="text-[8.5px] font-black text-[#0F172A]">Bankak</p>
            <p className="text-[6.5px] text-[#64748B]">Mobile wallet</p>
          </div>
          <div className="w-4 h-4 rounded-full bg-[#0D9488] flex items-center justify-center">
            <svg width="8" height="8" viewBox="0 0 24 24" fill="none">
              <path d="m5 12 5 5L20 7" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>

        {/* Cash */}
        <div className="rounded-[12px] px-3 py-2.5 flex items-center gap-2.5 border border-[#E2E8F0] bg-white">
          <div className="w-7 h-7 rounded-lg bg-[#F0FDF4] flex items-center justify-center shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <rect x="2" y="6" width="20" height="12" rx="2" stroke="#16A34A" strokeWidth="2"/>
              <circle cx="12" cy="12" r="3" stroke="#16A34A" strokeWidth="2"/>
              <path d="M6 12h.01M18 12h.01" stroke="#16A34A" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>
          <div className="flex-1">
            <p className="text-[8.5px] font-black text-[#0F172A]">Cash</p>
            <p className="text-[6.5px] text-[#64748B]">Physical payment</p>
          </div>
          <div className="w-4 h-4 rounded-full border-2 border-[#E2E8F0]" />
        </div>

        {/* Bank Transfer */}
        <div className="rounded-[12px] px-3 py-2.5 flex items-center gap-2.5 border border-[#E2E8F0] bg-white">
          <div className="w-7 h-7 rounded-lg bg-[#F0F9FF] flex items-center justify-center shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M3 9l9-6 9 6v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9z" stroke="#0284C7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M9 22V12h6v10" stroke="#0284C7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <div className="flex-1">
            <p className="text-[8.5px] font-black text-[#0F172A]">Bank Transfer</p>
            <p className="text-[6.5px] text-[#64748B]">Direct transfer</p>
          </div>
          <div className="w-4 h-4 rounded-full border-2 border-[#E2E8F0]" />
        </div>
      </div>

      {/* Confirm button */}
      <div className="px-3 pb-4 pt-3">
        <div
          className="w-full rounded-xl py-2.5 text-[8.5px] font-black text-white text-center"
          style={{ background: 'linear-gradient(135deg, #0F766E, #0D9488)' }}
        >
          Confirm · 8,140 SDG
        </div>
      </div>
    </div>
  );
}
